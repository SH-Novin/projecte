#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define MAX_LINE 1024
#define MAX_WORD 100
#define MAX_CATEGORIES 10
#define MAX_KEYWORDS 50
const char *separators = " \t\n.,;!?\"'()[]{}:-";

typedef struct category
{
    char name[MAX_WORD];
    char keyword[MAX_KEYWORDS][MAX_WORD];
    double coefficence[MAX_KEYWORDS];
    int keyword_count;
} cat;

int read_categories(FILE *cats_file, cat categories[])
{
    int cat_counter = 0;
    char cat_line[MAX_LINE];

    while (fgets(cat_line, MAX_LINE, cats_file) != NULL)
    {
        // test
        // cat_line[strcspn(cat_line, "\n")] = '\0';
        //
        cat *dcat = &categories[cat_counter];
        dcat->keyword_count = 0;

        char *token = strtok(cat_line, separators);
        if (token == NULL)
            continue;

        strncpy(dcat->name, token, MAX_WORD);
        dcat->name[MAX_WORD - 1] = '\0';

        int keyword_count = 0;
        while (keyword_count % 2 == 0 ? ((token = strtok(NULL, separators)) != NULL) : 1)
        {
            if (keyword_count % 2 == 0)
            {
                strncpy(dcat->keyword[keyword_count / 2], token, MAX_WORD);
                dcat->keyword[keyword_count / 2][MAX_WORD - 1] = '\0';
            }
            else
            {
                char *sahih = strtok(NULL, ".");
                char *ashar = strtok(NULL, separators);
                char coef[MAX_WORD];

                if (sahih && ashar)
                {
                    sprintf(coef, "%s.%s", sahih, ashar);
                    dcat->coefficence[keyword_count / 2] = atof(coef);
                }
                else if (sahih)
                {
                    dcat->coefficence[keyword_count / 2] = atof(sahih);
                }
                //sprintf(coef, "%s.%s", sahih, ashar);
                //dcat->coefficence[keyword_count / 2] = atof(coef);
            }
            keyword_count++;
        }
        dcat->keyword_count = keyword_count / 2;
        cat_counter++;
    }
    return cat_counter;
}

void calculate_relevance(FILE *file, cat categories[], int category_count)
{
    double revlance[MAX_KEYWORDS] = {0};
    char line[MAX_LINE];
    while (fgets(line, MAX_LINE, file) != NULL)
    {
        // test
        // line[strcspn(line, "\n")] = '\0';
        //
        char *token = strtok(line, separators);
        while (token)
        {
            for (char *p = token; *p; p++)
            {
                *p = tolower(*p);
            }

            for (int i = 0; i < category_count; i++)
            {
                for (int j = 0; j < categories[i].keyword_count; j++)
                {
                    if (strcmp(token, categories[i].keyword[j]) == 0)
                    {
                        revlance[i] += categories[i].coefficence[j];
                    }
                }
            }

            // refresh token
            token = strtok(NULL, separators);
        }
    }

    int max_rev_i = -1;
    double max_rev = -1;
    int Equal_rev = 0;
    for (int i = 0; i < category_count; i++)
    {
        if (revlance[i] > max_rev)
        {
            max_rev = revlance[i];
            max_rev_i = i;
            Equal_rev = 0;
        }
        else if (revlance[i] == max_rev)
        {
            Equal_rev = 1;
        }
    }

    if (Equal_rev || max_rev == 0)
    {
        printf("Unknown\n");
    }
    else
    {
        printf("%s\n", categories[max_rev_i].name);
    }
}
// تابع اصلی
int main(int argc, char *argv[])
{
    if (argc < 2)
    {
        printf("Usage: %s <categories file> <document files>\n", argv[0]);
        return 1;
    }

    FILE *cat_file = fopen(argv[1], "r");

    cat categories[MAX_CATEGORIES];
    int categories_count = read_categories(cat_file, categories);
    fclose(cat_file);

    FILE **doc_files = malloc((argc - 2) * sizeof(FILE *));
    for (int i = 2; i < argc; i++)
    {
        doc_files[i - 2] = fopen(argv[i], "r");
        calculate_relevance(doc_files[i - 2], categories, categories_count);
        fclose(doc_files[i - 2]);
    }

    // for (int i = 0; i < categories_count; i++)
    // {
    //     printf("%s keyword count: %d\n", categories[i].name, categories[i].keyword_count);
    //     for (int j = 0; j < categories[i].keyword_count; j++)
    //     {
    //         printf("\t%s : %0.1lf\n", categories[i].keyword[j], categories[i].coefficence[j]);
    //     }
    // }

    free(doc_files);
    return 0;
}